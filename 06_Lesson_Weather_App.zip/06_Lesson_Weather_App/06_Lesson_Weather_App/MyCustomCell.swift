//
//  MyCustomCell.swift
//  06_Lesson_Weather_App
//
//  Created by Stanly Shiyanovskiy on 13.12.16.
//  Copyright © 2016 Stanly Shiyanovskiy. All rights reserved.
//

import Foundation
import UIKit

class MyCustomCell: UITableViewCell {
    
    @IBOutlet weak var myView: UIImageView!
    @IBOutlet weak var myCellLabel: UILabel!
    
}
